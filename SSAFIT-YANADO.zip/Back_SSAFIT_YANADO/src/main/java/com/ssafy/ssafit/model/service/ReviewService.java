package com.ssafy.ssafit.model.service;

import java.util.List;

import com.ssafy.ssafit.model.dto.Review;

public interface ReviewService {
	public List<Review> getReviewList(String videoId);
	
	public void writeReivew(Review review);
	
	public void modifyReivew(Review review);
	
	public void removeReview(int reviewId);
	
	
}

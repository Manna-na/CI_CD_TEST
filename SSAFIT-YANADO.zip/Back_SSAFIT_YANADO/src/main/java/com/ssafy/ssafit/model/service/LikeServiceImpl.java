package com.ssafy.ssafit.model.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ssafit.model.dao.LikeDao;

@Service
public class LikeServiceImpl implements LikeService {

	
	@Autowired
	private LikeDao likeDao;
	
	@Override
	public int insertLike(String userId, String videoId) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("videoId", videoId);
		return likeDao.insertLike(map);
	}

	@Override
	public int deleteLike(int likeId) {
		return likeDao.deleteLike(likeId);
	}

	@Override
	public int selectLike(String userId, String videoId) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("videoId", videoId);
		return likeDao.selectLike(map);
	}

	@Override
	public int updataLikeCnt(String videoId, Integer delta) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("videoId", videoId);
		map.put("delta", delta);
		return likeDao.updataLikeCnt(map);
	}

}

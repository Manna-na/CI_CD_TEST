package com.ssafy.ssafit.model.dao;

import java.util.HashMap;

import com.ssafy.ssafit.model.dto.VideoRate;

public interface RateDao {
	int insertRate(VideoRate rate);
	int deleteRate(int rateId);
	int selectRate(HashMap<String, String> map);
	int updateRate(VideoRate rate);
}

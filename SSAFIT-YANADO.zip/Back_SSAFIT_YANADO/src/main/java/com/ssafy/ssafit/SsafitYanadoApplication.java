package com.ssafy.ssafit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsafitYanadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsafitYanadoApplication.class, args);
	}

}

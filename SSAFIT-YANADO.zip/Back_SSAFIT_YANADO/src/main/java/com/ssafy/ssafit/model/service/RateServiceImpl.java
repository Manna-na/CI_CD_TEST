package com.ssafy.ssafit.model.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ssafit.model.dao.RateDao;
import com.ssafy.ssafit.model.dto.VideoRate;

@Service
public class RateServiceImpl implements RateService {

	@Autowired
	private RateDao rateDao;
	
	@Override
	public int insertRate(VideoRate rate) {
		return rateDao.insertRate(rate);
	}

	@Override
	public int deleteRate(int rateId) {
		return rateDao.deleteRate(rateId);
	}

	@Override
	public int selectRate(String userId, String videoId) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("videoId", videoId);
		return rateDao.selectRate(map);
	}

	@Override
	public int updateRate(VideoRate rate) {
		return rateDao.updateRate(rate);
	}

}

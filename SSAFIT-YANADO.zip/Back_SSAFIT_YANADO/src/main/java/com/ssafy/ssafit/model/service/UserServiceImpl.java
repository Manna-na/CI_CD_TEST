package com.ssafy.ssafit.model.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.ssafy.ssafit.model.dao.UserDao;
import com.ssafy.ssafit.model.dto.User;

public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Override
	public int insertUser(User user) {
		return userDao.insertUser(user);
	}

	@Override
	public User selectUserById(String id) {
		return userDao.selectUserById(id);
	}

	@Override
	public int updateUser(User user) {
		return userDao.updateUser(user);
	}
	
	@Override
	public int deleteUser(String id) {
		return userDao.deleteUser(id);
	}

}

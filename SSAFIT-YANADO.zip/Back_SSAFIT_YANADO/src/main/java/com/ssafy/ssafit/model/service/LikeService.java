package com.ssafy.ssafit.model.service;

public interface LikeService {
	int insertLike(String userId, String videoId);
	int deleteLike(int likeId);
	int selectLike(String userId, String videoId);
	int updataLikeCnt(String videoId, Integer delta);
}

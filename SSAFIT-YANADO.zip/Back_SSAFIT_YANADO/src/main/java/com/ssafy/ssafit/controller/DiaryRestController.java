package com.ssafy.ssafit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.ssafit.model.dto.Diary;
import com.ssafy.ssafit.model.service.DiaryService;
import com.ssafy.ssafit.model.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api-diary")
@Api(tags="Diary 컨트롤러")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST })
public class DiaryRestController {

	@Autowired
	DiaryService ds;
	
	@Autowired
	UserService us;
	
	@GetMapping("/list")
	@ApiOperation(value = "특정 유저의 등록된 모든 일기를 반환한다.")
	public ResponseEntity<List<Diary>> selectAll(String userId){
		List<Diary> list = ds.selectDiaryAll(userId);
		return new ResponseEntity<List<Diary>>(list, HttpStatus.OK);
	}
	
	@Transactional
	@PutMapping("/update")
	@ApiOperation(value = "일기 정보를 수정한다")
	public ResponseEntity<String> update(Diary diary){
		if(us.selectUserById(diary.getUserId()) == null) {
			return new ResponseEntity<String>("NoSuchUser", HttpStatus.BAD_REQUEST);
		}
		ds.updateDiary(diary);
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
	
	@Transactional
	@PostMapping("/insert")
	@ApiOperation(value = "일기 정보를 등록한다.")
	public ResponseEntity<String> insert(Diary diary){
		if(us.selectUserById(diary.getUserId()) == null) {
			return new ResponseEntity<String>("NoSuchUser", HttpStatus.BAD_REQUEST);
		}
		ds.insertDiary(diary);
		return new ResponseEntity<String>("OK",HttpStatus.OK);
	}
	
	
	@Transactional
	@DeleteMapping("/delete")
	@ApiOperation(value = "일기를 삭제합니다.")
	public ResponseEntity<String> delete(int diaryId){
		ds.deleteDiary(diaryId);
		return new ResponseEntity<String>("OK", HttpStatus.OK);
	}
}

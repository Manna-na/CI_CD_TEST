package com.ssafy.ssafit.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ssafit.model.dao.ReviewDao;
import com.ssafy.ssafit.model.dto.Review;

@Service
public class ReviewServiceImpl implements ReviewService{

	@Autowired
	private ReviewDao reviewDao;
	
	@Override
	public List<Review> getReviewList(String videoId) {
		return reviewDao.selectReviewAll(videoId);
	}

	@Override
	public void writeReivew(Review review) {
		reviewDao.insertReview(review);
	}

	@Override
	public void modifyReivew(Review review) {
		reviewDao.updateReview(review);
	}

	@Override
	public void removeReview(int reviewId) {
		reviewDao.deleteReview(reviewId);
	}

}

package com.ssafy.ssafit.model.dao;

public interface AvatarDao {

}

package com.ssafy.ssafit.model.service;

public interface CharacterService {

}

package com.ssafy.ssafit.controller;

public class VideoRestController {

}

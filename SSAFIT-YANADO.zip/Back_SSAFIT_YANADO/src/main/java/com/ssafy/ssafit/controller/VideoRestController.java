package com.ssafy.ssafit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.ssafit.model.dto.Video;
import com.ssafy.ssafit.model.service.VideoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api-video")
@Api(tags="Video 컨트롤러")
public class VideoRestController {
	
	@Autowired
	private VideoService vs;

	// 비디오 생성
	@ApiOperation(value = "비디오 생성")
	@PostMapping("/create")
	public ResponseEntity<?> create(Video video){
		try{int result = vs.createVideo(video);
		//비디오 생성 실패했으면 예외
		if(result==0) throw new Exception();
		return new ResponseEntity<Video>(video, HttpStatus.CREATED);
		}
		catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	// 비디오 상세보기
	@ApiOperation(value = "비디오 상세보기")
	@GetMapping("/detail/{videoId}")
	public ResponseEntity<Video> readVideo(@PathVariable String videoId){
		Video video = vs.readVideo(videoId);
		return new ResponseEntity<Video>(video, HttpStatus.OK);
	}
	
	// 비디오 전체 가져오기? 근데 이게 필요한가?
	@ApiOperation(value="비디오 전체 가져오기")
	@GetMapping("/video")
	public ResponseEntity<List<Video>> video(){
		List<Video> videos = vs.selectAllVideo();
		return new ResponseEntity<List<Video>>(videos, HttpStatus.OK);
	}
	
	// 비디오 좋아요 순으로 10개 가져오기
	@ApiOperation(value="비디오 좋아요 순으로 10개 가져오기")
	@GetMapping("/video/like")
	public ResponseEntity<?> videoByLikeCnt(){
		List<Video> videos = vs.selectVideoByLikeCnt();
		if(videos==null || videos.size()==0) {
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
		
		return new ResponseEntity<List<Video>>(videos, HttpStatus.OK);
	}
	
	// 비디오 조회수 순으로 10개 가져오기
	@ApiOperation(value="비디오 조회수 순으로 10개 가져오기")
	@GetMapping("video/view")
	public ResponseEntity<?> videosByViewCnt(){
		List<Video> videos = vs.selectVideoByViewCnt();
		if(videos==null || videos.size()==0) {
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Video>>(videos, HttpStatus.OK);
		
	}
	
	//예외 처리
		private ResponseEntity<String> exceptionHandling(Exception e) {
	        e.printStackTrace();
	        return new ResponseEntity<String>("Sorry: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}

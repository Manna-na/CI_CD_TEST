package com.ssafy.ssafit.model.service;

import com.ssafy.ssafit.model.dto.User;

public interface UserService {
	int insertUser(User user);
	User selectUserById(String id);
	int updateUser(User user);
	int deleteUser(String id);
}

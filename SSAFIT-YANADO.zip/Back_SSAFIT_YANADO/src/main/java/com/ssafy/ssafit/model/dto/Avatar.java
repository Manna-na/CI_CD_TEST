package com.ssafy.ssafit.model.dto;

public class Avatar {

}

package com.ssafy.ssafit.model.dao;

import java.util.HashMap;

public interface LikeDao {
	int insertLike(HashMap<String, String> map);
	int deleteLike(int likeId);
	int selectLike(HashMap<String, String> map);
	int updataLikeCnt(HashMap<String, Object> map);
}

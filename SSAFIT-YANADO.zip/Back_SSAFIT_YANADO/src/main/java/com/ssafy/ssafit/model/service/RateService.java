package com.ssafy.ssafit.model.service;

import com.ssafy.ssafit.model.dto.VideoRate;

public interface RateService {
	int insertRate(VideoRate rate);
	int deleteRate(int rateId);
	int selectRate(String userId, String videoId);
	int updateRate(VideoRate rate);
}

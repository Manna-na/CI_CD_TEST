import Vue from "vue";
import VueRouter from "vue-router";
import VideoView from "../views/VideoView.vue";
import VideoList from "@/components/video/VideoList.vue";
import VideoSearch from "@/components/video/VideoSearch.vue";
// import ReviewList from "@/components/review/ReviewList.vue";
// import ReviewDetail from "@/components/review/ReviewDetail.vue";
// import ReviewCreate from "@/components/review/ReviewCreate.vue";
import UserLogin from "@/components/user/UserLogin.vue";
import UserRegist from "@/components/user/UserRegist.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    component: VideoView,
    children: [
      {
        path: "",
        name: "videoList",
        component: VideoList,
      },
      {
        path: "/search",
        name: "videoSearch",
        component: VideoSearch,
      },
      // {
      //   path: ":videoId",
      //   name: "videoDetail",
      //   component: VideoDetail,
      //   children: [
      //     {
      //       path: "",
      //       name: "ReviewList",
      //       component: ReviewList,
      //     },
      //     {
      //       path: ":reviewId",
      //       name: "ReviewDetail",
      //       component: ReviewDetail,
      //     },
      //     {
      //       path: "create",
      //       name: "ReviewCreate",
      //       component: ReviewCreate,
      //     },
      //   ],
      // },
    ],
  },
  {
    path: "/login",
    name: "login",
    component: UserLogin,
  },
  {
    path: "/regist",
    name: "regist",
    component: UserRegist,
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;

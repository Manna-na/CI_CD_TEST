<template>
  <div id="app">
    <header-nav></header-nav>
    <router-view />
    <footer-nav></footer-nav>
  </div>
</template>
<!-- class="text-white" -->
<script>
import HeaderNav from '@/components/common/HeaderNav.vue';
import FooterNav from '@/components/common/FooterNav.vue';
export default {
  components: {
    HeaderNav,
    FooterNav,
  },
};
</script>

<style>
hhtml,
body {
  height: 100%;
  margin: 0;
  padding: 0;
}

#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

footer-nav {
  margin-top: auto;
}
</style>

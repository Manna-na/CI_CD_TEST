<template>
   <footer class="text-center text-lg-start" style="background-color: #F5F5F9;">
    <div class="container d-flex justify-content-center py-5">
      <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #F5F5F9;">
        <!-- <b-img src="@/assets/bear.png"></b-img> -->
        <b-img :src="require('@/assets/bear.png')" style="justify-content: center;"></b-img>
      </button>
      <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #F5F5F9;">
        <i class="fab fa-youtube"></i>
      </button>
      <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #F5F5F9;">
        <i class="fab fa-instagram"></i>
      </button>
      <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #F5F5F9;">
        <i class="fab fa-twitter"></i>
      </button>
    </div>

    <!-- Copyright -->
    <div class="text-center text-black p-3" style="background-color: #EEEEF9;">
      © 2023 Copyright: YND
      <a class="text-black" href="https://www.ssafy.com/ksp/jsp/swp/swpMain.jsp">ssafy.com</a>
    </div>
    <!-- Copyright -->
  </footer>
</template>

<script>
export default {};
</script>

<style></style>

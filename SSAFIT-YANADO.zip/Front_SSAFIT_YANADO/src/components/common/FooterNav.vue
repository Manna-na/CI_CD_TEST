<template>
   <footer class="text-center text-lg-start" style="background-color: #F5F5F9;">
    <div class="container d-flex justify-content-center py-3">
        <b-img :src="require('@/assets/bears.png')" width="80px" height="40px" style="justify-content: center;"></b-img>
        <b-img :src="require('@/assets/bears.png')" width="80px" height="40px" style="justify-content: center;"></b-img>
    </div>

    <!-- Copyright -->
    <div class="text-center text-black p-3" style="background-color: #EEEEF9;">
      © 2023 Copyright: YND
      <a class="text-black" href="https://www.ssafy.com/ksp/jsp/swp/swpMain.jsp">ssafy.com</a>
    </div>
    <!-- Copyright -->
  </footer>
</template>

<script>
export default {};
</script>

<style></style>

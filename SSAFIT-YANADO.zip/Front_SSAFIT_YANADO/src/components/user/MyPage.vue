<template>
  <div>

    <form
        class="container shadow-lg"
        style="
          width: 800px;
          padding-left: 50px;
          padding-right: 50px;
          margin-top: 50px;
          margin-bottom: 10px;
        "
      >
        <div class="text-center mt-5" style="font-weight: 500; margin-top: 50px">
          <div>
            <b-icon icon="person-circle" font-scale="2"/>
          </div>
          <h4 class="text-center mb-0 mr-1">Mypage</h4>
        </div>
        <hr />
        <!-- 2 column grid layout with text inputs for the first and last names -->
        <div class="row mb-4">
          <div class="col">
            <div class="text-center form-outline">
              <p style="font-size: 20px">당신의 아이디는 </p>
            </div>
          </div>
          <div class="col">
            <div class="text-center form-outline">
              <p style="font-size: 20px">{{ user.userId }}</p>
            </div>
          </div>
        </div>
    
        <!-- Text input -->
        <div class="row mb-4">
          <div class="col">
            <div class="text-center form-outline">
              <p style="font-size: 20px">당신의 이름은</p>
            </div>
          </div>
          <div class="col">
            <div class="text-center form-outline">
              <p style="font-size: 20px">{{ user.name }}</p>
            </div>
          </div>
        </div>
        <!-- Text input -->
        <b-input-group>
          <b-input-group-prepend is-text>
            <b-icon icon="envelope"></b-icon>
          </b-input-group-prepend>
          <b-form-input
            type="email"
            id="form6Example4"
            readonly
            :value="user.email"
            class="form-control"
          ></b-form-input>
        </b-input-group>
        <div class="form-outline mb-4">
        </div>
    
        <!-- Email input -->
        <div class="form-outline mb-4">
          <p style="font-weight: bolder; font-size: larger; margin-bottom: 5px">
            비밀번호 변경
          </p>
          <label class="form-label" for="form6Example5"
            >현재 비밀번호를 입력해주세요</label
          >
          <input type="text" id="form6Example5" class="form-control" />
        </div>
    
        <!-- Number input -->
        <div class="form-outline mb-4">
          <label class="form-label" for="form6Example6"
            >바꾸실 비밀번호를 입력해주세요</label
          >
          <input type="text" id="form6Example6" class="form-control" />
        </div>
    
        <!-- Number input -->
        <div class="form-outline mb-4">
          <label class="form-label" for="form6Example6"
            >다시 한번 바꾸실 비밀번호를 입력해주세요</label
          >
          <input type="text" id="form6Example6" class="form-control" />
        </div>
    
        <!-- Submit button -->
        <b-row class="mb-2 mt-2">
          <b-col>
            <button class="btn btn-primary btn-default btn-sm mt-2 w-100 mb-5 ">
              비밀번호 수정</button
            ><br />
          </b-col>
        </b-row>
      </form>
      <div class="nav justify-content-center">
        <button
          class="btn btn-danger btn-default "
          @click="showModal = true"
        >
          회원 탈퇴
        </button>
        <Modal
          :show="showModal"
          :userId="user.userId"
          @close="showModal = false"
          @deleteUser="deleteUser"
        >
        </Modal>
      </div>
  </div>
</template>

<script>
import axios from "axios";
import Modal from "../deleteUserModal.vue";
import router from "../../router";
export default {
  name: "MyPage",
  components: {
    Modal,
  },
  data() {
    return {
      user: {
        userId: "",
        password: "",
        email: "",
        name: "",
      },
      inputPassword: "",
      chkPassword: "",
      showModal: false,
      loginUser : sessionStorage.getItem("loginUser"),
      userId : sessionStorage.getItem("userId"),
    };
  },
  created() {
    axios({
      url: `http://localhost:9999/api-user/${this.userId}`,
      method: "POST",
      data: this.loginUser,
    }).then((res) => {
      this.user = res.data;
    });
  },
  methods: {
    userModify() {},
    deleteUser(userId, chkPassword) {
      let loginUser = this.loginUser;
      axios({
        url: `http://localhost:9999/api-user/delete`,
        method: "DELETE",
        data: {
          userId,
          chkPassword,
          loginUser,
        },
      })
        .then((res) => {
          if (res.data === "OK") {
            alert("회원 탈퇴가 완료되었습니다.");
            sessionStorage.removeItem("loginUser");
            sessionStorage.removeItem("userId");
            router.push("/login");
          }
        })
        .catch((res) => {
          if(res.response.data === "BadPassword"){
            alert("잘못된 비밀번호입니다.");
            this.showModal=false;
          }
        });
    },
  },
};
</script>
<style></style>

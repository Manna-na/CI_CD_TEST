<template>
  <div class="container">
    <div class="d-flex justify-content-center align-items-center" style="height: 60vh;">
      <b-container fluid>
        <b-input-group class="mb-2">
          <b-form-input type="text" id="id" v-model="userId" placeholder="아이디"></b-form-input>
        </b-input-group>
        <b-input-group class="mb-2">
          <b-form-input type="password" id="password" v-model="password" placeholder="비번"></b-form-input>
        </b-input-group>
        <div class="d-flex justify-content-center" style="margin-top:20px">
        <b-button variant="primary" @click="login">로그인</b-button>
      </div>
      </b-container>
    </div>
  </div>
</template> 

<script>
export default {
  name: "UserLogin",
  data() {
    return {
      userId: "",
      password: ""
    }
  },
  methods: {
    login() {
      let user = {
        userId: this.userId,
        password: this.password,
      };
      this.$store.dispatch('userLogin', user)
    }
  },
}
</script>

<style></style>
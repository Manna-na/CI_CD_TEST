<template>
   <div class="container" >
    <div>
        <div class="searchBar" style="margin-top: auto;">
          <b-input-group style="width: 800px;" placeholder="검색어를 입력ㅇ루어ㅏㄹ" class="mt-3">
            <b-form-input class="rounded-pill"  type="text" v-model="keyword"></b-form-input>
            <b-input-group-append>
              <b-button class="rounded-pill" variant="info" @click="search">Button</b-button>
            </b-input-group-append>
          </b-input-group>
        </div>
    </div>
    <div>
        
    <h3>검색 결과</h3>
    <ul class="youtube-list">
      <video-item
        v-for="video in videos"
        :key="video.id.videoId"
        :video="video"
      ></video-item>
    </ul>
  </div>
    <!-- <li @click="clickVideo">
    <img :src="video.snippet.thumbnails.default.url" />
    {{ video.snippet.title }}
  </li>
    <b-row cols="1" cols-sm="2" cols-md="4">
      <b-card
        v-for="(video, index) in videos"
        :key="index"
        :video="video"
        :title="movie.title"
        :img-src="video.snippet.thumbnails.default.url"
        img-top
      >
        <b-card-text>
          {{ movie.overview }}
        </b-card-text>
        <b-list-group flush>
          <b-list-group-item>개봉일 : {{ movie.release_date }}</b-list-group-item>
          <b-list-group-item>언어 : {{ movie.original_language }}</b-list-group-item>
        </b-list-group>
      </b-card>
    </b-row>  -->
</div>
</template>

<script>
import { mapState } from 'vuex';
import VideoItem from './VideoItem.vue';

export default {
    components: { VideoItem },
    computed: {
      ...mapState(['videos']),
    },
    name: "VideoSearch",
    data() {
    return {
      keyword: '',
    };
  },
   
    methods:{
        search() {
      this.$store.dispatch('searchYoutube', this.keyword.concat(' ', '운동'));
    },
    }
}
</script>

<style>

</style>
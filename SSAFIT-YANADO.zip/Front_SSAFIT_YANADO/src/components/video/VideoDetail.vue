<template>
  <div v-if="video">
    <h2>영상 보기!</h2>
    <iframe
      width="560"
      height="315"
      :src="videoURL"
      title="YouTube video player"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      allowfullscreen
    ></iframe>
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  name: 'YoutubeVideoDetail',
  computed: {
    ...mapState(['video']),
    videoURL() {
      const videoId = this.video.id.videoId;
      return `https://www.youtube.com/embed/${videoId}`;
    },
  },
};
</script>

<style></style>
    <!-- <div class="container">
      <b-card no-body class="overflow-hidden">
    <b-row no-gutters>
      <b-col md="6">
        <b-card-img src="https://picsum.photos/400/400/?image=20" alt="Image" class="rounded-0"></b-card-img>
      </b-col>
      <b-col md="6">
        <b-card-body title="Horizontal Card">
          <b-card-text>
            This is a wider card with supporting text as a natural lead-in to additional content.
            This content is a little bit longer.
          </b-card-text>
        </b-card-body>
      </b-col>
    </b-row>
  </b-card>
      <h3>비디오 상세보기</h3>
      <div>{{ video.videoTitle }}</div>
      <div>
      <b-embed
    type="iframe"
    aspect="16by9"
    :src="`https://www.youtube.com/embed/${video.videoId}`"
    allowfullscreen
  ></b-embed>
      </div>
      <div>{{ video.part }}</div>
      <div>{{ video.channelName }}</div>
      <div>{{ video.viewCnt }}</div>
    </div>
  </template>
  
  <script>
  import { mapState } from 'vuex';
  import ReviewList from "@/components/review/ReviewList.vue"
  
  export default {
    name: 'VideoDetail',
    computed: {
      ...mapState(['video']),
    },
    conponents:{
        ReviewList
    },
    created() {
      const pathName = new URL(document.location).pathname.split('/');
      const videoId = pathName[pathName.length - 1];
      this.$store.dispatch('getVideo', videoId);
    },
  };
  </script>
  
  <style></style>
   -->
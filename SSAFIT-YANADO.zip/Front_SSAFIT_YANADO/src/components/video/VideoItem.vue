<template>

    <li @click="clickVideo">
      <img :src="video.snippet.thumbnails.default.url" />
      {{ video.snippet.title }}<br>
      {{ video.snippet.channelTitle }}<br>
        {{ video.snippet.description }}
    </li>
  </template>
  
  <script>
  export default {
    name: 'VideoItem',
    props: {
      video: {
        type: Object,
        required: true,
      },
    },
    methods: {
      clickVideo() {
        this.$store.dispatch('clickVideo', this.video);
      },
    },
  };
  </script>
  
  <style></style>
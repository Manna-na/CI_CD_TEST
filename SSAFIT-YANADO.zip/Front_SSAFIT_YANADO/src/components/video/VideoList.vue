<template>
  <div class="container">
    <section class="new-index"> 
      <div class="index">
        
        
        <h1>Get some exercise</h1>
        <div class="searchBar">
          <b-input-group style="width: 800px;" placeholder="검색어를 입력ㅇ루어ㅏㄹ" class="mt-3">
            <b-form-input class="rounded-pill"></b-form-input>
            <b-input-group-append>
              <b-button class="rounded-pill" variant="info">Button</b-button>
            </b-input-group-append>
          </b-input-group>
        </div>
      </div>  
    </section> 
    <h4 class="text-front"><b>좋아요순</b></h4>

    <!-- <div class="d-flex justify-content-center">
      <b-form inline>
        <b-form-select v-model="mode">
          <b-form-select-option value="1">부위</b-form-select-option>
        </b-form-select>
        <b-form-input
          type="text"
          v-model="keyword"
          class="m-1"
          placeholder="Enter your name"
        />
        <b-button @click="search" variant="danger">검색</b-button>
      </b-form>
    </div> -->
    <!-- <b-row cols="1" cols-sm="2" cols-md="4" class="justify-content-center">  
        <b-card
          v-for="(video, index) in videoes"
          :key="index"
          :title="video.channelName"
          :img-src="require(`@/assets/${video.img}`)"
          class="m-2"
          img-top
        >
          <b-card-text>
            <b-link :to="`/video/${video.videoId}`">{{ video.videoTitle }}</b-link>
          </b-card-text>
          <b-list-group flush>
            <b-list-group-item>part : {{ video.part }}</b-list-group-item>
            <b-list-group-item><b-badge variant="light">viewCnt : {{ video.viewCnt }}</b-badge></b-list-group-item>
          </b-list-group>
        </b-card>
      </b-row> -->
    <b-row>
      <b-col cols="12">
        <carousel :perPage="4" :autoplay="true" :navigationEnabled="true">
          <div class="cardShadow">
          <slide class="p-2">    
            <b-card 
              title="Card Title 1"
              img-src="https://picsum.photos/600/300/?image=25"
              img-alt="Image"
              img-top
              tag="article"
              style="border: 1px solid rgba(0, 0, 0, 0);"
            >
              <b-card-text style="width: 210px; margin-bottom: 0px;"> 제목1 </b-card-text>
              <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
            </b-card>
          </slide>
        </div>
        <div class="cardShadow">
          <slide class="p-2">
            <div class="image-zoom">
            <b-card
              title="Card Title 2"
              img-src="https://picsum.photos/600/300/?image=25"
              img-alt="Image"
              img-top
              tag="article"
            >
              <b-card-text style="width: 210px; margin-bottom: 0px;"> 제목2 </b-card-text>
              <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
            </b-card>
          </div>
          </slide>
          </div>
          <slide class="p-2">
            <b-card
              title="Card Title 3"
              img-src="https://picsum.photos/600/300/?image=25"
              img-alt="Image"
              img-top
              tag="article"
            >
              <b-card-text style="width: 210px; margin-bottom: 0px;"> 제목3 </b-card-text>
              <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
            </b-card>
          </slide>
          <slide class="p-2">
            <b-card
              title="Card Title 3"
              img-src="https://picsum.photos/600/300/?image=25"
              img-alt="Image"
              img-top
              tag="article"
              title-style="
    margin-bottom: 0px;
"
            >
              <b-card-text style="width: 210px; margin-bottom: 0px;"> 제목3.5</b-card-text>
              <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
            </b-card>
          </slide>
          <slide class="p-2">
            <b-card
              title="Card Title 4"
              img-src="https://picsum.photos/600/300/?image=25"
              img-alt="Image"
              img-top
              tag="article"
              
            >
              <b-card-text style="width: 210px; margin-bottom: 0px;"> 제목4 </b-card-text>
              <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;"> Detail </b-button>
            </b-card>
          </slide>
        </carousel>
      </b-col>
    </b-row>
    <div class="mb-5">
      <h4 class="text-front"><b>조회수많은 수</b></h4>
      <!-- <h4 class="text-front" style="font: small-caps bold 24px/1 sans-serif;">조회수많은 수</h4> -->
      <b-row class>
        <b-col cols="12">
          <carousel
            :perPage="3"
            :autoplay="true"
            :navigationEnabled="true"
            class="p-2"
          >
            <slide class="p-2">
              <b-card
                title="Card Title 1"
                img-src="https://picsum.photos/600/300/?image=25"
                img-alt="Image"
                img-top
                tag="article"
              >
                <b-card-text> 제목1 </b-card-text>
                <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
              </b-card>
            </slide>
            <slide class="p-2">
              <b-card
                title="Card Title 2"
                img-src="https://picsum.photos/600/300/?image=25"
                img-alt="Image"
                img-top
                tag="article"
              >
                <b-card-text> 제목2 </b-card-text>

                <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
              </b-card>
            </slide>
            <slide class="p-2">
              <b-card
                title="Card Title 3"
                img-src="https://picsum.photos/600/300/?image=25"
                img-alt="Image"
                img-top
                tag="article"
              >
                <b-card-text> 제목3 </b-card-text>

                <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
              </b-card>
            </slide>
            <slide class="p-2">
              <b-card
                title="Card Title 4"
                img-src="https://picsum.photos/600/300/?image=25"
                img-alt="Image"
                img-top
                tag="article"
              >
                <b-card-text> 제목4 </b-card-text>
                <b-button href="#" variant="primary" style="border-bottom-width: 0px;padding-bottom: 3px;padding-top: 3px;border-top-width: 0px;">Detail</b-button>
              </b-card>
            </slide>
          </carousel>
        </b-col>
      </b-row>
    </div>
  </div>
</template>

<script>
export default {
  name: "VideoList",
  data() {
    return {
      // mode: 1,
      // keyword: "",
    };
  },
  // computed: {
  //   ...mapState(["videoes"]),
  //   videoCount() {
  //     return this.videoes.length;
  //   },
  // },

  // created() {
  //   this.$store.dispatch("getVideoes");
  // },
  methods: {
    handleHover(hovered) {
        this.isHovered = hovered
      }
    //   search() {
    //     const payload = {
    //       mode: this.mode,
    //       keyword: this.keyword,
    //     };
    //     this.$store.dispatch("getPartlyVideoes", payload);
    //   },
  },
};
</script>

<style>
.new-index{
  display: flex;
}
.index{
  background-image: linear-gradient(rgba(255,255,255,0.5), rgba(255,255,255,0.5)),url("@/assets/요가사진 (2).jpg"); 
  width: 1300px;
  height: 360px;
}
.searchBar{
  margin-top: 200px;
  display: flex;
  justify-content: center;
}
h1 {
  position: absolute;
  color: #000000;  
  font-size: 14rem;
  line-height: 0.9;
  text-align: center;
  padding-top: 150px;
  padding-left: 150px;
}
.text-front{
  padding-top: 30px;
}
.image-zoom:hover img {
      transform: scale(1.1);
    }
.cardShadow{
  box-shadow: 0 2px 4px 0 rgba(0,0,0,.2);
}
</style>

<template>
  <div>카카오 api 가져와서 운동 장소 보여주는 공간이에요 근데 못했어요
    
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
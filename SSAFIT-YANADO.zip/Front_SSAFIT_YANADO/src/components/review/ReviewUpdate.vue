<template>
    <div>
      <h2>리뷰 수정</h2>
      <fieldset>
        <legend>수정</legend>
        <label for="title">제목 : </label>
        <input type="text" id="title" v-model="review.reviewTitle" /><br />
        <label for="writer">작성자 : </label>
        <input type="text" id="writer" readonly v-model="review.userId" /><br />
        <label for="content">내용 : </label>
        <textarea
          id="content"
          cols="30"
          rows="10"
          v-model="review.content"
        ></textarea>
        <button @click="updateReview">수정</button>
      </fieldset>
    </div>
  </template>
  
  <script>
  import { mapState } from 'vuex';
  
  export default {
    name: 'ReviewUpdate',
    computed: {
      ...mapState(['review']),
    },
    methods: {
      updateReview() {
        let updateReview = {
          userId: this.review.userId,
          reviewTitle: this.review.reviewTitle,
          content: this.review.content,
        };
        this.$store.dispatch('updateReview', updateReview);
      },
    },
  };
  </script>
  
  <style></style>
  
<template>
    <div>
      <h3>리뷰 상세보기</h3>
      <div>{{ review.reviewId}}</div>
      <div>{{ review.userId }}</div>
      <div>{{ review.reviewTitle }}</div>
      <div>{{ review.regDate }}</div>
      <div>{{ review.content }}</div>
      <div>{{ review.viewCnt }}</div>
  
      <button @click="moveUpdate">수정</button>
      <button @click="deleteReview">삭제</button>
    </div>
  </template>
  
  <script>
  import { mapState } from 'vuex';
  
  export default {
    name: 'ReviewDetail',
    computed: {
      ...mapState(['review']),
    },
    created() {
      const pathName = new URL(document.location).pathname.split('/');
      const id = pathName[pathName.length - 1];
      this.$store.dispatch('getReview', id);
    },
    methods: {
      moveUpdate() {
        this.$router.push({ name: 'reviewUpdate' });
      },
      deleteBoard() {
        this.$store.dispatch('reviewBoard', this.review);
      },
    },
  };
  </script>
  
  <style></style>
  
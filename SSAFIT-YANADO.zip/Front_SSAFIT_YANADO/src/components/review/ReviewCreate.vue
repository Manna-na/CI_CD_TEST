<template>
    <div>
      <h3>리뷰 등록</h3>
      <fieldset>
        <legend>등록</legend>
        <label for="title">제목 : </label>
        <input type="text" id="title" v-model="reviewTitle" /><br />
        <label for="writer">작성자 : </label>
        <input type="text" id="writer" v-model="userId" readonly/><br />
        <label for="content">내용 : </label>
        <textarea id="content" cols="30" rows="10" v-model="content"></textarea>
        <button @click="createReview">등록</button>
      </fieldset>
    </div>
</template>
  
<script>
    export default {
      name: 'ReviewCreate',
      data() {
        return {
          reviewTitle: '',
          userId: '',
          content: '',
        };
      },
      methods: {
        createReview() {
          let review = {
            id: 0,
            reviewTitle: this.reviewTitle,
            userId: this.userId,
            content: this.content,
          };
          this.$store.dispatch('createReview', review);
        },
      },
    };
</script>
  
<style></style>
  
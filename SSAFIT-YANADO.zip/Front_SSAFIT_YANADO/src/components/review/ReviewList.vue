<template>
    <div class="container">
      <h3>리뷰 목록</h3>
      <hr />
      <div>
        <b-table-simple
          hover
          :items="reviews"
        >
        <b-thead class="text-center">
          <b-tr>
            <b-th>번호</b-th>
            <b-th>제목</b-th>
            <b-th>글쓴이</b-th>
            <b-th>조회수</b-th>
            <b-th>등록일</b-th>
          </b-tr>
        </b-thead>
        <b-tbody class="text-center">
          <b-tr v-for="review in pageReviewList" :key="review.reviewId">
            <b-td>{{ review.reviewId }}</b-td>
            <b-td>
              <b-link :to="`/${review.videoId}/${review.reviewId}`">{{
                review.reviewTitle
              }}</b-link>
            </b-td>
            <b-td>{{ review.userId }}</b-td>
            <b-td>{{ review.viewCnt }}</b-td>
            <b-td>{{ review.regDate }}</b-td>
          </b-tr>
        </b-tbody>
        </b-table-simple>
      </div>
      <b-pagination
        v-model="currentPage"
        :total-rows="reviewCount"
        :per-page="perPage"
        align="center"
      ></b-pagination>
    </div>
  </template>
  
  <script>
  import { mapState } from 'vuex';
  
  export default {
    name: 'ReviewList',
    data() {
      return {
        currentPage:1,
        perPage: 5,
      };
    },
    computed: {
      ...mapState(['reviews']),
      reviewCount() {
        return this.reviews.length
      },
      pageReviewList(){
        return this.reviews.slice(
          (this.currentPage-1) * this.perPage,
          this.currentPage*this.perPage
        )
      }
    },
    created() {
      this.$store.dispatch('getReviews');
    },
  };
  </script>
  
  <style></style>
  
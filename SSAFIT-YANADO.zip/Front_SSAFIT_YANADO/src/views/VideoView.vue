<template>
    <div class="container">
      <!-- <h2 class="text-center mt-3">video 목록</h2> -->
      <!-- 링크를 여러개를 만들면 좋겠다. -->
      <!-- <router-link to="/tmdb/popular">인기순위</router-link> -->
      <router-view />
      <router-view name="ReviewList"/>
    </div>
  </template>
  
  <script>
  export default {
      name: "VideoView"
  }
  </script>
  
  <style>
  
  </style>
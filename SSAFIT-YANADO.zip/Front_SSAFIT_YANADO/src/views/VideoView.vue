<template>
  <div class="container">
    <router-view />
    <router-view name="ReviewView" />
  </div>
</template>

<script>
export default {
  name: "VideoView",
};
</script>

<style></style>

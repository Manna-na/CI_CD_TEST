<template>
  <div class="container">
    <h2>Reviewview</h2>
    <router-view />
  </div>
</template>

<script>
export default {
  name: "ReviewView",
};
</script>

<style></style>

<template>
    <div class="container">
      <router-view />
    </div>
  </template>
  
  <script>
  export default {
    name: "DiaryView",
  };
  </script>
  
  <style></style>
import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";
// import router from "@/router";

Vue.use(Vuex);

// const REST_API = `http://localhost:9999/ssafit`;

export default new Vuex.Store({
  state: {
    videos : [],
    video: null
  },
  getters: {
  },
  mutations: {
    SEARCH_YOUTUBE(state, videos){
      state.videos = videos
    }
    ,CLICK_VIDEO(state, video){
      state.video = video
    }
  },
  actions: {
    // 비동기 통신은 여기서 진행시켜!!!
    searchYoutube({commit}, payload){
      const URL = "https://www.googleapis.com/youtube/v3/search";
      const API_KEY = process.env.VUE_APP_YOUTUBE_API_KEY;
      axios({
          url: URL,
          method: "GET",
          params: {
              key: API_KEY,
              part: "snippet",
              q: payload,
              type: "video",
              maxResults: 10,
          },
      })
      .then((res) => {
        console.log(res.data.items);
        commit("SEARCH_YOUTUBE", res.data.items)
      })
      .catch((err) => console.log(err));
    },
    // 여기에 있는 payload에는 video 객체가 들어온다.
    clickVideo({commit}, payload){
      commit("CLICK_VIDEO", payload)
    }
  },
})
//   state: {
//     videoes: [],
//     video: {},
//     searchVideos:[],
//     reviews:[],
//     review:{},
//     users:[],
//     user: {},
//     loginUser:null,
//   },
//   getters: {  
//     userCnt(state){
//       return state.users.length;
//     },
//     reviewCnt(state){
//       return state.reviews.length;
//     },
//     searchVideoCnt(state){
//       return state.searchVideos.length;
//     },
//   },
//   mutations: {
//     GET_VIDEOES(state, payload){
//       state.videoes = payload;
//     },
//     GET_VIDEO(state, payload){
//       state.video = payload;
//     },
//     GET_PARTLYVIDEOES(state, payload){
//       state.videoes = payload;
//     },
//     GET_REVIEWS(state, payload) {
//       state.reviews = payload;
//     },
//     GET_REVIEW(state, payload) {
//       state.review = payload;
//     },
//     GET_USERS(state, payload) {
//       state.users = payload;
//     },
//     INSERT_REVIEW(state, payload) {
//       state.reviews.push(payload);
//     },
//     REGIST_USER(state, payload) {
//       state.users.push(payload);
//     },
//     SET_LOGIN_USER(state, user){
//       state.loginUser = user;
//     },
//     LOGOUT(state){
//       state.loginUser = null;
//     },
//   },
//   actions: {
//     getVideoes({ commit }, payload) {
//       let params = null;
//       if (payload) params = payload;

//       const API_URL = `${REST_API}/video/list`;
//       axios({
//         url: API_URL,
//         method: "GET",
//         params,
//         // headers: {
//         //   "access-token": sessionStorage.getItem("access-token"),
//         // },
//       })
//         .then((res) => {
//           commit("GET_VIDEOES", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     getVideo({ commit }, videoId) {
//       const API_URL = `${REST_API}/video/detail/${videoId}`;
//       axios({
//         url: API_URL,
//         method: "GET",
//         // headers: {
//         //   "access-token": sessionStorage.getItem("access-token"),
//         // },
//       })
//         .then((res) => {
//           commit("GET_VIDEO", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     getPartlyVideoes({ commit }, payload) {
//       let params = null;
//       if (payload) params = payload;

//       const API_URL = `${REST_API}/video/partly/${params.keyword}`;
//       axios({
//         url: API_URL,
//         method: "GET",
//         params,
//         // headers: {
//         //   "access-token": sessionStorage.getItem("access-token"),
//         // },
//       })
//         .then((res) => {
//           console.log(res.data);
//           commit("GET_PARTLYVIDEOES", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     getReviews({ commit }, videoId) {
//       const API_URL = `${REST_API}/review/list/${videoId}`;
//       axios({
//         url: API_URL,
//         method: "GET",
//       })
//         .then((res) => {
//           commit("GET_REVIEWS", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     getReview({ commit }, reviewId) {
//       const API_URL = `${REST_API}/review/detail/${reviewId}`;
//       axios({
//         url: API_URL,
//         method: "GET",
//       })
//         .then((res) => {
//           commit("GET_REVIEW", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },getUsers({ commit }) {
//       const API_URL = `${REST_API}/user/list`;
//       axios({
//         url: API_URL,
//         method: "GET",
//       })
//         .then((res) => {
//           commit("GET_USERS", res.data);
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     insertReview({ commit }, review) {
//       const API_URL = `${REST_API}/review/insert`;
//       axios({
//         url: API_URL,
//         method: "POST",
//         params: review,
//       })
//         .then(() => {
//           commit("INSERT_REVEW", review);
//           router.push({name:"VideoDetail", params:{videoId:review.videoId}});
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     updateReview({ commit }, review) {
//       const API_URL = `${REST_API}/review/update`;
//       axios({
//         url: API_URL,
//         method: "PUT",
//         params: review,
//       }).then(() => {
//         commit("UPDATE_REVIEW", review);
//         router.push({name:"VideoDetail", params:{videoId:review.videoId}});
//       });
//     },
//     deleteReview({ state }, review) {
//       const API_URL = `${REST_API}/review/delete/${review.reviewId}`;
//       axios({
//         url: API_URL,
//         method: "DELETE",
//       })
//         .then(() => {
//           let index;
//           for (let i = 0; i < state.reviews.length; i++) {
//             if (state.reviews[i].reviewId === review.reviewId) {
//               index = i;
//             }
//           }
//           state.reviews.splice(index, 1);
//           router.push({name:"VideoDetail", params:{videoId:review.videoId}});
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     registUser({ commit }, user) {
//       const API_URL = `${REST_API}/user/regist`;
//       axios({
//         url: API_URL,
//         method: "POST",
//         params: user,
//       })
//         .then(() => {
//           commit("REGIST_USER", user);
//           router.push("/login");
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//     userLogin({ commit }, user) {
//       const API_URL = `${REST_API}/user/login`;
//       axios({
//         url: API_URL,
//         method: "POST",
//         params: user,
//       })
//         .then((res) => {
//           alert("로그인기능 구현했는데 시간이 없어서 나머지를 못했어요");
//           sessionStorage.setItem("access-token", res.data["access-token"]);
//           commit("SET_LOGIN_USER"); //필요하다면 데이터도 같이 올려보내라
//         })
//         .catch((err) => {
//           console.log(err);
//         });
//     },
//   },
//   modules: {},
// });

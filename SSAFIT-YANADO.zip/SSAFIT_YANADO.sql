DROP SCHEMA IF EXISTS `SSAFIT_YANADO_db` ;
CREATE SCHEMA IF NOT EXISTS `SSAFIT_YANADO_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `SSAFIT_YANADO_db` ;

DROP TABLE IF EXISTS `User` ;
CREATE TABLE IF NOT EXISTS `User` (
  `userId` VARCHAR(20) NOT NULL,
  `password` VARCHAR(16) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `name` VARCHAR(20) NOT NULL,
  `img` VARCHAR(200) DEFAULT NULL,
  PRIMARY KEY (`userid`))
ENGINE = InnoDB;

INSERT INTO `User` (`userId`, `password`, `email`,`name`) 
VALUE
('ssafy', '1234', 'ssafy@ssafy.com', '박두현'),
('wngh', '5678', 'wngh@ssafy.com', '최주호'),
('hanna', '13579', 'hanna@ssafy.com', '김한나');

DROP TABLE IF EXISTS `Video` ;
CREATE TABLE IF NOT EXISTS `Video` (
  `videoId` VARCHAR(100) NOT NULL,
  `channelName` VARCHAR(200) NOT NULL,
  `videoTitle` VARCHAR(200) NOT NULL,
  `likeCnt` int DEFAULT 0,
  `viewCnt` int DEFAULT 0,
  `rate` double DEFAULT 0,
  PRIMARY KEY (`videoId`))
ENGINE = InnoDB;

INSERT INTO `Video` (`videoId`, `channelName`, `videoTitle`, `likeCnt`, `viewCnt`, `rate`) 
VALUE
('gMaB-fG4u4g', 'ThankyouBUBU', '전신 다이어트 최고의 운동 [칼소폭 찐 핵핵매운맛]',3,7,5.0),
('swRNeYw1JkY', 'ThankyouBUBU', '하루 15분! 전신 칼로리 불태우는 다이어트 운동',2,5,4.5),
('54tTYO-vU2E','ThankyouBUBU','상체 다이어트 최고의 운동 BEST [팔뚝살/겨드랑이살/등살/가슴어깨라인]',1,3,4.0),
('QqqZH3j_vH0','ThankyouBUBU','상체비만 다이어트 최고의 운동 [상체 핵매운맛]',0,1,0),
('tzN6ypk6Sps','김강민','하체운동이 중요한 이유? 이것만 보고 따라하자 ! [하체운동 교과서]',0,1,0),
('u5OgcZdNbMo','GYM종국','저는 하체 식주의자 입니다',0,1,0),
('PjGcOP-TQPE','ThankyouBUBU','11자복근 복부 최고의 운동 [복근 핵매운맛]',0,1,0),
('7TLk7pscICk','SomiFit','(Sub)누워서하는 5분 복부운동!! 효과보장! (매일 2주만 해보세요!)',0,1,0),
('2DRvc74GgYM','관절사용설명서','앉아서 하는 스트레칭 루틴! | 의자 스트레칭',0,1,0);


DROP TABLE IF EXISTS `Review` ;
CREATE TABLE IF NOT EXISTS `Review` (
`reviewId` int AUTO_INCREMENT,
`videoId` VARCHAR(100) NOT NULL,
FOREIGN KEY (`videoId`)
    REFERENCES `Video` (`videoId`)
    ON DELETE Cascade,
`userId` VARCHAR(20) NOT NULL,
FOREIGN KEY (`userId`)
    REFERENCES `User` (`userId`)
    ON DELETE CASCADE,
`content` VARCHAR(400) NOT NULL,
`date` DATE NOT NULL,
  PRIMARY KEY (`reviewId`))
ENGINE = InnoDB;

INSERT INTO `review` (`videoId`, `userId`, `content`,`date`) 
VALUE
('gMaB-fG4u4g', 'ssafy', '싸탈했어요1',20230510),
('gMaB-fG4u4g', 'wngh', '운동했어요2',20230511),
('gMaB-fG4u4g','hanna','운동했어요3',20230512),
('swRNeYw1JkY', 'ssafy', '운동했어요1',20230513),
('swRNeYw1JkY', 'wngh','운동했어요2',20230514),
('swRNeYw1JkY','hanna','운동했어요3',20230515),
('54tTYO-vU2E', 'ssafy','운동했어요1',20230516),
('54tTYO-vU2E', 'wngh','운동했어요2',20230517),
('54tTYO-vU2E','hanna','운동했어요3',20230518);

DROP TABLE IF EXISTS `Pause` ;
CREATE TABLE IF NOT EXISTS `Pause` (
`pauseId` int AUTO_INCREMENT,
`videoId` VARCHAR(100) NOT NULL,
FOREIGN KEY (`videoId`)
    REFERENCES `Video` (`videoId`)
    ON DELETE CASCADE,
`userId` VARCHAR(20) NOT NULL,
FOREIGN KEY (`userId`)
    REFERENCES `User` (`userId`)
    ON DELETE CASCADE,
`pauseTime` int NOT NULL,
  PRIMARY KEY(`pauseId`)
  )
ENGINE = InnoDB;

INSERT INTO `Pause` (`videoId`, `userId`, `pauseTime`) 
VALUE
('gMaB-fG4u4g', 'ssafy', 600),
('swRNeYw1JkY', 'wngh', 300);

DROP TABLE IF EXISTS `Diary`;
CREATE TABLE IF NOT EXISTS `Diary` (
`diaryId` int AUTO_INCREMENT,
`userId` VARCHAR(20) NOT NULL,
FOREIGN KEY (`userId`)
    REFERENCES `SSAFIT_YANADO_db`.`User` (`userId`)
    ON DELETE CASCADE,
`date` date NOT NULL,
`content` VARCHAR(1500) NOT NULL,
`manjok` int DEFAULT 0,
`img` VARCHAR(200) DEFAULT NULL,
`workout` VARCHAR(40) DEFAULT NULL,
PRIMARY KEY (`diaryId`))
ENGINE = InnoDB;

INSERT INTO `Diary` (`userId`, `date`, `content`,`manjok`,`workout`) 
VALUE
('ssafy', 20230518, '싸탈하기위해 주호와 밥을 먹었어요' ,5,'다리'),
('ssafy', DATE_FORMAT(now(),'%Y-%m-%d'), '덕분에 싸탈했어요 기분 최고에요' ,5,'전신');

DROP TABLE IF EXISTS `VideoLike`;
CREATE TABLE IF NOT EXISTS `VideoLike` (
`likeId` int AUTO_INCREMENT,
`videoId` VARCHAR(100) NOT NULL,
FOREIGN KEY (`videoId`)
    REFERENCES `Video` (`videoId`)
    ON DELETE CASCADE,
`userId` VARCHAR(20) NOT NULL,
FOREIGN KEY (`userId`)
    REFERENCES `User` (`userId`)
    ON DELETE CASCADE,
PRIMARY KEY(`likeId`)
)
ENGINE = InnoDB;

INSERT INTO `VideoLike` (`videoId`, `userId`) 
VALUE
('gMaB-fG4u4g', 'ssafy'),
('gMaB-fG4u4g', 'wngh'),
('gMaB-fG4u4g', 'hanna'),
('swRNeYw1JkY', 'ssafy'),
('swRNeYw1JkY', 'hanna'),
('54tTYO-vU2E', 'wngh');

DROP TABLE IF EXISTS `VideoRate`;
CREATE TABLE IF NOT EXISTS `VideoRate` (
`rateId` int AUTO_INCREMENT,
`videoId` VARCHAR(100) NOT NULL,
	FOREIGN KEY (`videoId`)
    REFERENCES `Video` (`videoId`)
    ON DELETE CASCADE,
`userId` VARCHAR(20) NOT NULL,
FOREIGN KEY (`userId`)
    REFERENCES `User` (`userId`)
    ON DELETE CASCADE,
`rate` int NOT NULL,
PRIMARY KEY (`rateId`)
)
ENGINE = InnoDB;

INSERT INTO `VideoRate` (`videoId`, `userId`, `rate`) 
VALUE
('gMaB-fG4u4g', 'ssafy',5),
('swRNeYw1JkY', 'ssafy',4),
('swRNeYw1JkY', 'wngh',5),
('54tTYO-vU2E', 'ssafy',3),
('54tTYO-vU2E', 'wngh',4),
('54tTYO-vU2E', 'hanna',5);


select * from User;
select * from Video;
select * from Review;
select * from Pause;
select * from Diary;
select * from VideoLike;